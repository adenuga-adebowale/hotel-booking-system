# Lagoon House Hotel — Booking & Operations System

A full-stack hotel reservation and front-desk application for a fictional premium hotel on Victoria Island, Lagos. The repository contains an Angular standalone frontend and a TypeScript/Express API using Prisma + SQLite.

## Quick start

Requirements: Node.js 22.22.3+ (or a supported Node 24 release) and npm 10+. Angular 22.2.6 is pinned as the current stable major line for this project.

1. From the project root run `npm run setup`. The setup script creates `server/.env` from `server/.env.example` when it is missing, installs workspaces, generates Prisma Client, syncs the schema and seeds the database.
2. Keep the safe local defaults for local demos. Change the JWT secrets before exposing the app to a network.
3. Start everything:

```bash
npm run setup
npm run dev
```

Open **http://localhost:4200**. API health: **http://localhost:4000/api/health**.

`npm run setup` creates the local environment file if needed, installs workspaces, generates Prisma Client, creates/updates the SQLite schema and seeds the demo hotel. `npm run dev` starts the API and Angular dev server together. The SQLite database is created at `server/prisma/dev.db` when using the default `DATABASE_URL="file:./dev.db"` from the server working directory.

## Demo accounts

All demo accounts use password: **`HotelDemo123!`**

| Role | Email |
|---|---|
| Administrator | `admin@lagoonhouse.test` |
| Receptionist | `reception1@lagoonhouse.test` |
| Receptionist | `reception2@lagoonhouse.test` |
| Guest 1–5 | `guest1@lagoonhouse.test` through `guest5@lagoonhouse.test` |

Seed data: Lagoon House Hotel, Victoria Island; four room types; 20 individually numbered rooms; one promo code (`WELCOME10`); one admin, two receptionists, five guest accounts; and 30 bookings distributed across past/current/future dates and different statuses. Room photography uses remote Unsplash images, so internet access is required for photos.

## Short plan / architecture

### Data model (ERD summary)

```text
User ──< Booking >── Room >── RoomType
  │          │         │
  │          ├──< Payment
  │          └──── Review
  └──< AuditLog
Hotel (profile, policies, facilities, photos)
SeasonalRate (optional room-type scope) · PromoCode
```

A booking always references one physical `Room`. The API checks date-range overlap using half-open intervals (`existing.checkIn < requested.checkOut && existing.checkOut > requested.checkIn`), ignores expired pending holds, validates guest capacity and calculates the complete NGN price. Booking creation and conflict checking happen in a Prisma interactive transaction and a single-process mutex. For a multi-instance PostgreSQL deployment, replace the in-process mutex with a PostgreSQL advisory lock (or a room/date exclusion constraint) around the transaction.

### API endpoints

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| GET | `/api/health` | Public | Health check |
| POST | `/api/auth/register` | Public | Guest registration |
| POST | `/api/auth/login` | Public | Login; returns short-lived JWT |
| GET | `/api/auth/me` | Authenticated | Current user |
| GET | `/api/hotel` | Public | Hotel profile |
| GET | `/api/rooms` | Public | Room types and inventory |
| GET | `/api/availability?checkIn=YYYY-MM-DD&checkOut=YYYY-MM-DD&adults=2&children=0` | Public | Actual room/date availability and price breakdown |
| POST | `/api/bookings` | Public or authenticated | Create a room hold or pay-at-hotel reservation |
| GET | `/api/bookings/:reference` | Public | Booking confirmation lookup by reference |
| POST | `/api/bookings/:id/pay` | Public demo adapter | Simulated payment outcome |
| GET | `/api/bookings/mine` | Guest | Own bookings |
| POST | `/api/bookings/:reference/cancel` | Guest owner / staff / admin | Cancel and calculate charge |
| GET | `/api/staff/today` | Receptionist / admin | Arrivals, departures, in-house and cleaning |
| GET | `/api/staff/bookings?q=` | Receptionist / admin | Search booking reference, name or phone |
| PATCH | `/api/staff/bookings/:id/status` | Receptionist / admin | Change booking/check-in/check-out status |
| PATCH | `/api/staff/rooms/:id/status` | Receptionist / admin | Change room operational status |
| POST | `/api/reviews` | Guest | Review a completed stay |
| GET | `/api/admin/summary?from=&to=` | Admin | Booking/revenue/occupancy summary |
| GET | `/api/admin/export.csv` | Admin | CSV booking export |

Validation uses Zod. Auth uses Argon2 password hashes and signed JWT access tokens. Protected endpoints use role middleware. API requests are rate-limited and Helmet/CORS are enabled. A Swagger UI is not bundled in this local build; this table is the concise API reference.

## Role guides

### Guest

1. Use the date and guest search on the home page.
2. Select an available room. The returned total includes nights, tax and service fee.
3. Enter guest/contact details and optional promo code.
4. Choose simulated online payment or pay at the hotel.
5. Keep the `HB-YYYY-NNNNNN` booking reference shown on the confirmation screen.
6. Sign in to see your bookings and cancel eligible reservations.

### Receptionist

1. Sign in as `reception1@lagoonhouse.test` or `reception2@lagoonhouse.test`.
2. Open Front Desk for today's arrivals, departures, in-house guests and rooms requiring cleaning.
3. Search all bookings from the live booking overview endpoint (UI currently displays the latest list).
4. Use Check in / Check out actions to progress a confirmed reservation. A checked-out room is automatically marked Cleaning.

### Administrator

1. Sign in as `admin@lagoonhouse.test`.
2. Open Admin for the front-desk view and seeded room inventory overview.
3. Use the protected admin summary and CSV export endpoints for reporting.

## Payments

The development gateway is `SimulatedGateway`. Set `SIMULATED_PAYMENT_OUTCOME=success`, `failure`, or `pending` in `server/.env` to demo outcomes. A successful payment marks the booking Confirmed; a failed payment cancels it; a pending outcome leaves it awaiting payment until the 10-minute hold expires. The hold-expiry worker checks every 30 seconds.

The `PaymentGateway` interface and `PaystackAdapter` placeholder document the integration boundary. To enable Paystack or Flutterwave, implement server-side initialisation, verify signed provider webhooks, and update Payment + Booking inside a database transaction. Store provider references only. **Never collect or store card numbers, expiry/CVV, or raw payment credentials.** Do not expose provider secret keys to Angular. Live payment is intentionally disabled until provider credentials and webhook verification are configured.

Pay-at-hotel currently confirms the reservation immediately. `DEPOSIT_PERCENT` is provided as a configuration placeholder; the deposit policy is not yet enforced by the demo booking logic.

## Email and notifications

The mock mail service logs confirmation and cancellation emails to the API console. `emailTemplate()` provides the HTML template boundary. To use a real provider, set `MAIL_PROVIDER=smtp`, configure `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, and `SMTP_PASS`, and replace the documented transport stub in `server/src/services/mailer.ts` with Nodemailer or your provider SDK. Add a durable queue/worker for one-day reminders and post-checkout review requests before production. Current implementation sends booking confirmation and cancellation notifications only.

## Configuration

Copy `.env.example` to `server/.env`. Required variables are checked at API startup: `JWT_ACCESS_SECRET`, `JWT_REFRESH_SECRET`, `DATABASE_URL`, `CLIENT_ORIGIN`. The example values are for local development only. Change secrets and restrict CORS in production.

| Variable | Purpose |
|---|---|
| `PORT` | API port (default 4000) |
| `DATABASE_URL` | Prisma SQLite connection; PostgreSQL URL for deployment |
| `JWT_ACCESS_SECRET` / `JWT_REFRESH_SECRET` | Signing secrets (refresh-token rotation is not yet implemented) |
| `CLIENT_ORIGIN` | Exact allowed frontend origin |
| `HOLD_MINUTES` | Temporary booking hold (default 10) |
| `TAX_RATE` | Tax fraction (default 0.075) |
| `SERVICE_FEE` | Flat fee in NGN (default 5000) |
| `PAYMENT_PROVIDER` | `simulated` for demo |
| `SIMULATED_PAYMENT_OUTCOME` | Optional demo outcome |

### PostgreSQL path

Change the Prisma datasource provider to `postgresql`, set a PostgreSQL `DATABASE_URL`, then run `npm run db:generate -w server` and `npm run db:push -w server` (or use reviewed Prisma migrations). Add a PostgreSQL advisory lock or exclusion constraint for room/date concurrency before running multiple API instances.

## Tests

Run `npm test` from the root. The unit suite covers nightly pricing/tax/discounts, invalid dates, overlap and back-to-back stays, expired holds, and cancellation charges. These are domain tests; a true simultaneous multi-process integration test against PostgreSQL is still required before production.

## Assumptions

- One hotel/property is managed by this installation.
- Prices, fees and tax are integer Nigerian Naira amounts; tax defaults to 7.5%, service fee to ₦5,000.
- Weekends (Friday and Saturday nights) default to a 10% uplift. Seasonal rates override the weekend multiplier when a matching seasonal rule is found.
- Maximum stay is 30 nights. Capacity is checked against the room type's adult and child limits.
- A booking is for one physical room. Multiple-room reservations require separate bookings.
- Free cancellation is at least 48 hours before check-in; 50% charge inside 48 hours; full charge on/after check-in. Actual refunds are not processed by the simulated gateway.
- Pay-at-hotel confirms immediately in the demo; deposit enforcement is a future configuration enhancement.
- Guest can browse and reserve without an account; registration/login is available for account bookings/history.
- The demo uses remote Unsplash image URLs and mock email. Production should use owned/optimised image storage and a real mail provider.
- The in-memory booking mutex protects one API process. A distributed lock or database-level constraint is mandatory for horizontal scaling.

## Troubleshooting

- **`Missing required environment variable`**: copy `.env.example` to `server/.env`; check the required secrets and `DATABASE_URL`.
- **Port already in use**: stop the other service or change `PORT` in `server/.env`; update `API_URL` in `client/src/app/core/api.service.ts` if changing the API port.
- **Cannot reach hotel server**: start from the root with `npm run dev`; verify `http://localhost:4000/api/health` and that Angular is on port 4200.
- **Login says incorrect email or password**: use one of the exact demo emails above and `HotelDemo123!`. If the database was previously seeded with different data, run `npm run seed -w server` to reset and reseed it.
- **Prisma client/schema mismatch**: run `npm run db:generate -w server` then `npm run db:push -w server`.
- **Images are blank**: Unsplash is remote; check internet access or replace URLs with local images.
- **Angular build errors after changing versions**: remove `node_modules` and the lockfile, run `npm install`, then `npm run build`.

## Acceptance checklist

- [ ] `npm run setup` completes on a clean checkout.
- [ ] `npm run dev` starts both services; health endpoint returns `status: ok`.
- [ ] All eight demo accounts can sign in with `HotelDemo123!`.
- [ ] Invalid credentials show “Incorrect email or password”; stopped API shows a server-unreachable message.
- [ ] Guest search returns only rooms with no overlapping active bookings.
- [ ] Back-to-back check-out/check-in dates remain available.
- [ ] Invalid dates, past check-in and over-capacity guests are rejected.
- [ ] Pricing shows nights, tax, fees, discount and total in NGN.
- [ ] Create a booking, pay successfully, and verify the booking reference/status.
- [ ] Set `SIMULATED_PAYMENT_OUTCOME=failure` and verify failed payment does not confirm the booking.
- [ ] Set `SIMULATED_PAYMENT_OUTCOME=pending`, wait beyond `HOLD_MINUTES`, and verify the room is released.
- [ ] Try two simultaneous bookings for the same room/date in a load test; only one should succeed (multi-instance lock required for production).
- [ ] Receptionist can check in and check out a confirmed booking; room becomes Occupied then Cleaning.
- [ ] Guest can see their account bookings and cancel within the configured policy.
- [ ] Admin CSV export downloads booking records.

## Production readiness: incomplete / simplified items

This is a runnable MVP foundation, not a security-audited production deployment. Specifically: refresh-token rotation/session revocation is not implemented; the Angular UI has no complete account registration page, room detail route, image lightbox, full admin CRUD for hotel/rooms/staff/rates/promos, drag calendar, advanced filters, PDF receipts/reports, or review submission screen; staff walk-in/phone booking creation and room-status controls are API-only; admin UI is currently an inventory/front-desk overview rather than the full analytics console; payment adapter is a documented stub and simulated only; real SMTP transport and reminder/review notification scheduler are not wired; booking PDF generation is not wired; audit records cover key booking/status actions but not every admin mutation; multi-process concurrency needs a PostgreSQL lock/constraint; uploads are not enabled; and end-to-end browser tests are not included. Do not process real payments or expose this build publicly until these controls are implemented, tested and reviewed.
