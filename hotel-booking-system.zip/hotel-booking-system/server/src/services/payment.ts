export type PaymentOutcome='success'|'failure'|'pending';
export interface PaymentGateway { initialise(amount:number, reference:string):Promise<{status:PaymentOutcome;checkoutUrl?:string}>; verify(reference:string):Promise<PaymentOutcome> }
export class SimulatedGateway implements PaymentGateway {
 async initialise(_amount:number, reference:string):Promise<{status:PaymentOutcome;checkoutUrl?:string}> { const outcome=(process.env.SIMULATED_PAYMENT_OUTCOME || 'success') as PaymentOutcome; return {status:outcome,checkoutUrl:`/payment/simulate/${reference}`}; }
 async verify(_reference:string):Promise<PaymentOutcome> { return (process.env.SIMULATED_PAYMENT_OUTCOME || 'success') as PaymentOutcome; }
}
// Production adapter contract: initialise with Paystack/Flutterwave secret on the server, verify signed webhooks,
// then update Payment and Booking inside a database transaction. Never accept/store PAN or CVV.
export class PaystackAdapter implements PaymentGateway {
 async initialise(_amount:number,_reference:string):Promise<{status:PaymentOutcome;checkoutUrl?:string}> { throw new Error('Configure PAYSTACK_SECRET_KEY and implement provider API before enabling live payments.'); }
 async verify(_reference:string):Promise<PaymentOutcome> { throw new Error('Configure signed Paystack webhook verification before enabling live payments.'); }
}
