import { describe,it,expect } from 'vitest';
import { calculatePrice } from './pricing.js'; import { isRoomAvailable } from './availability.js'; import { cancellationCharge } from './cancellation.js';
const date=(s:string)=>new Date(`${s}T00:00:00.000Z`);
describe('pricing',()=>{
 it('calculates nights, tax, fees and total in kobo-free NGN integer units',()=>{const p=calculatePrice({checkIn:date('2027-02-01'),checkOut:date('2027-02-03'),baseRate:50000,taxRate:.075,fees:5000});expect(p.nights).toBe(2);expect(p.subtotal).toBe(100000);expect(p.tax).toBe(7500);expect(p.total).toBe(112500);});
 it('applies promo discounts before tax',()=>{const p=calculatePrice({checkIn:date('2027-02-01'),checkOut:date('2027-02-02'),baseRate:100000,taxRate:.1,fees:0,discountPercent:10});expect(p.discount).toBe(10000);expect(p.tax).toBe(9000);expect(p.total).toBe(99000);});
 it('rejects invalid date ranges and stays above 30 nights',()=>{expect(()=>calculatePrice({checkIn:date('2027-02-02'),checkOut:date('2027-02-02'),baseRate:1})).toThrow();expect(()=>calculatePrice({checkIn:date('2027-01-01'),checkOut:date('2027-02-05'),baseRate:1})).toThrow();});
});
describe('availability and overlap',()=>{
 const existing=[{checkIn:date('2027-03-01'),checkOut:date('2027-03-04'),status:'CONFIRMED'}];
 it('rejects overlapping reservations including partial overlaps',()=>{expect(isRoomAvailable(date('2027-03-03'),date('2027-03-05'),existing)).toBe(false);expect(isRoomAvailable(date('2027-02-28'),date('2027-03-02'),existing)).toBe(false);});
 it('allows back-to-back stays',()=>{expect(isRoomAvailable(date('2027-03-04'),date('2027-03-06'),existing)).toBe(true);});
 it('ignores expired pending holds',()=>{const hold=[{...existing[0],status:'PENDING_PAYMENT',holdExpiresAt:date('2027-02-01')}];expect(isRoomAvailable(date('2027-03-02'),date('2027-03-03'),hold,date('2027-02-02'))).toBe(true);});
});
describe('cancellation policy',()=>{it('is free more than 48 hours before check-in',()=>{expect(cancellationCharge(100000,new Date(Date.now()+72*3600000))).toBe(0);});it('charges half within 48 hours',()=>{expect(cancellationCharge(100000,new Date(Date.now()+24*3600000))).toBe(50000);});it('charges full amount on or after check-in',()=>{expect(cancellationCharge(100000,new Date(Date.now()-1000))).toBe(100000);});});

describe('concurrent room booking protection',()=>{
 it('allows only one of two simultaneous requests for the same room and dates',async()=>{
  const {withBookingLock}=await import('./booking-lock.js');
  const reservations:Array<{checkIn:Date;checkOut:Date;status:string}> = [];
  const attempt=()=>withBookingLock(async()=>{
   await new Promise(resolve=>setTimeout(resolve,5));
   const start=date('2027-04-10'),end=date('2027-04-12');
   if(!isRoomAvailable(start,end,reservations))return false;
   reservations.push({checkIn:start,checkOut:end,status:'CONFIRMED'});return true;
  });
  const outcomes=await Promise.all([attempt(),attempt()]);
  expect(outcomes.filter(Boolean)).toHaveLength(1);
  expect(reservations).toHaveLength(1);
 });
});
