export function overlaps(startA: Date, endA: Date, startB: Date, endB: Date) { return startA < endB && endA > startB; }
export function isRoomAvailable(checkIn: Date, checkOut: Date, existing: Array<{checkIn:Date;checkOut:Date;status:string;holdExpiresAt?:Date|null}>, now = new Date()) {
  return !existing.some(b => ['CONFIRMED','CHECKED_IN','PENDING_PAYMENT'].includes(b.status) && (b.status !== 'PENDING_PAYMENT' || !b.holdExpiresAt || b.holdExpiresAt > now) && overlaps(checkIn,checkOut,b.checkIn,b.checkOut));
}
