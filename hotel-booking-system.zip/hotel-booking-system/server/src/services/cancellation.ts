export function cancellationCharge(total:number, checkIn:Date, now=new Date(), freeHours=48, latePercent=50) {
 const hours=(checkIn.getTime()-now.getTime())/3600000;
 if(hours>=freeHours) return 0;
 if(hours<=0) return total;
 return Math.round(total*latePercent/100);
}
