// Serialises booking-critical sections in a single API process. For horizontal scaling,
// replace with a database advisory lock or an exclusion constraint on room/date ranges.
let queue: Promise<unknown> = Promise.resolve();
export function withBookingLock<T>(operation:()=>Promise<T>):Promise<T> {
  const task=queue.then(operation,operation);
  queue=task.then(()=>undefined,()=>undefined);
  return task;
}
