export async function sendMail(to:string, subject:string, html:string) {
 if ((process.env.MAIL_PROVIDER || 'mock') === 'mock') { console.info(`[MOCK EMAIL] to=${to} subject=${subject}`); return; }
 // SMTP integration point: wire Nodemailer using SMTP_HOST/PORT/USER/PASS in production.
 if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) throw new Error('SMTP configuration is incomplete.');
 console.info(`[EMAIL QUEUED] ${to}: ${subject}`); // replace with provider transport before production.
}
export const emailTemplate=(title:string,body:string)=>`<div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;padding:32px;color:#172b3a"><h1>${title}</h1><p>${body}</p><p>Lagoon House Hotel · Lagos, Nigeria</p></div>`;
