export type RateRule = { startDate: Date; endDate: Date; multiplier: number };
export function calculatePrice(input: { checkIn: Date; checkOut: Date; baseRate: number; taxRate?: number; fees?: number; discountPercent?: number; seasonalRates?: RateRule[] }) {
  const { checkIn, checkOut, baseRate } = input;
  if (!(checkIn instanceof Date) || !(checkOut instanceof Date) || checkOut <= checkIn) throw new Error('Check-out must be after check-in.');
  const nights = Math.ceil((Date.UTC(checkOut.getFullYear(),checkOut.getMonth(),checkOut.getDate())-Date.UTC(checkIn.getFullYear(),checkIn.getMonth(),checkIn.getDate()))/86400000);
  if (nights < 1 || nights > 30) throw new Error('Stay must be between 1 and 30 nights.');
  let subtotal = 0;
  for (let i=0;i<nights;i++) {
    const day = new Date(checkIn); day.setDate(day.getDate()+i);
    const seasonal = (input.seasonalRates ?? []).find(r => day >= r.startDate && day < r.endDate);
    const weekend = day.getDay()===5 || day.getDay()===6;
    const multiplier = seasonal?.multiplier ?? (weekend ? 1.1 : 1);
    subtotal += Math.round(baseRate * multiplier);
  }
  const discount = Math.round(subtotal * Math.min(100,Math.max(0,input.discountPercent ?? 0))/100);
  const taxable = subtotal - discount;
  const tax = Math.round(taxable * (input.taxRate ?? 0.075));
  const fees = input.fees ?? 5000;
  return { nights, nightlyRate: Math.round(subtotal/nights), subtotal, tax, fees, discount, total: taxable+tax+fees };
}
