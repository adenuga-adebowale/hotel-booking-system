import { Injectable, inject } from '@angular/core'; import { HttpClient } from '@angular/common/http'; import { Observable } from 'rxjs';
export const API_URL='http://localhost:4000/api';
@Injectable({providedIn:'root'}) export class ApiService { private http=inject(HttpClient); get<T>(path:string):Observable<T>{return this.http.get<T>(API_URL+path)} post<T>(path:string,body:unknown):Observable<T>{return this.http.post<T>(API_URL+path,body)} patch<T>(path:string,body:unknown):Observable<T>{return this.http.patch<T>(API_URL+path,body)} }
