import { bootstrapApplication } from '@angular/platform-browser';
import { provideRouter, Routes } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { AppComponent } from './app/app.component';
import { authInterceptor } from './app/core/auth.interceptor';
import { roleGuard } from './app/core/role.guard';
const routes: Routes = [
 {path:'',component:AppComponent},
 {path:'login',component:AppComponent},
 {path:'rooms',component:AppComponent},
 {path:'book/:roomId',component:AppComponent},
 {path:'confirmation/:reference',component:AppComponent},
 {path:'my-bookings',component:AppComponent,canActivate:[roleGuard]},
 {path:'staff',component:AppComponent,canActivate:[roleGuard],data:{roles:['ADMIN','RECEPTIONIST']}},
 {path:'admin',component:AppComponent,canActivate:[roleGuard],data:{roles:['ADMIN']}},
 {path:'**',redirectTo:''}
];
bootstrapApplication(AppComponent,{providers:[provideRouter(routes),provideHttpClient(withInterceptors([authInterceptor]))]}).catch(err=>console.error(err));
